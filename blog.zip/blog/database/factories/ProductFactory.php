<?php

use Faker\Generator as Faker;

$factory->define(App\product::class, function (Faker $faker) {
    return [
      'name' => $faker->name,
      'slug' => $faker->slug,
      'price' => $faker->randomNumber(2) ,
      'description' => $faker->text(200) ,
      'image' => $faker->imageUrl(640, 480),
    ];
});
