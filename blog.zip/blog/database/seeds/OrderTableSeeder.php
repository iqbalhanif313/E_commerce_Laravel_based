<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class OrderTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {

        $faker = Faker::create();

      DB::table('orders')->insert([
        'user_id'=>$faker->randomElement(['1']),
        'product_id'=>$faker->randomElement(['1']),
        'quantity'=>$faker->randomElement(['1','2','3','4']),
    ]);
        DB::table('orders')->insert([
          'user_id'=>$faker->randomElement(['1']),
          'product_id'=>$faker->randomElement(['1']),
          'quantity'=>$faker->randomElement(['1','2','3','4']),
      ]);
        DB::table('orders')->insert([
          'user_id'=>$faker->randomElement(['1']),
          'product_id'=>$faker->randomElement(['1']),
          'quantity'=>$faker->randomElement(['1','2','3','4']),
      ]);
    }
}
