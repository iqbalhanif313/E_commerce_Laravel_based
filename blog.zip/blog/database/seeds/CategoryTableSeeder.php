<?php

use Illuminate\Database\Seeder;

class CategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('category')->insert([
          'name' => 'Consina',
          'slug'=>str_slug('Consina'),
          'created_at' => DB::raw('now()'),
          'updated_at' => DB::raw('now()'),
      ]);

        DB::table('category')->insert([
          'name' => 'Eiger',
          'slug' => str_slug('Eiger'),
          'created_at' => DB::raw('now()'),
          'updated_at' => DB::raw('now()'),
      ]);

        DB::table('category')->insert([
          'name' => 'Deuter',
          'slug' => str_slug('Deuter'),
          'created_at' => DB::raw('now()'),
          'updated_at' => DB::raw('now()'),
      ]);
        DB::table('category')->insert([
          'name' => 'The North Face',
          'slug' => str_slug('The North Face'),
          'created_at' => DB::raw('now()'),
          'updated_at' => DB::raw('now()'),
      ]);

    }
}
