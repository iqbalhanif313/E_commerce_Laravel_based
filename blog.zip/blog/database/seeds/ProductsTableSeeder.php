<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $faker = Faker::create();
      $category_id=DB::table('category')->select('id')->get();

      //dd($category_id);
      DB::table('products')->insert([
        'name' => 'Eiger LS Dallas Vest 3',
        'slug' => str_slug('Eiger LS Dallas Vest 3','-'),
        'category_id'=>$faker->randomElement(['1','2','3','4']),
        'price' => '250000' ,
        'description' => $faker->text(200) ,
        'image' => 'jaket.jpg',
    ]);

        DB::table('products')->insert([
          'name' => 'Eiger LS Sweat Forward 4',
          'slug' => str_slug('Eiger LS Sweat Forward 4','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket2.jpg',
      ]);

        DB::table('products')->insert([
          'name' => 'Eiger LS Jacket Motion',
          'slug' => str_slug('Eiger LS Jacket Motion','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket3.jpg',
      ]);
        DB::table('products')->insert([
          'name' => 'Consina Piedra 2',
          'slug' => str_slug('Consina Piedra 2','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket4.jpg',
      ]);
        DB::table('products')->insert([
          'name' => 'Consina Piedra 3',
          'slug' => str_slug('Consina Piedra 3','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket5.jpg',
      ]);
        DB::table('products')->insert([
          'name' => 'Eiger LS Sweat Forward',
          'slug' => str_slug('Eiger LS Sweat Forward','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket6.jpg',
      ]);

        DB::table('products')->insert([
          'name' => 'Eiger LS Dallas Vest 5',
          'slug' => str_slug('Eiger LS Dallas Vest 5','-'),
          'category_id'=>$faker->randomElement(['1','2','3','4']),
          'price' => '250000' ,
          'description' => $faker->text(200) ,
          'image' => 'jaket7.jpg',
      ]);
    }
}
