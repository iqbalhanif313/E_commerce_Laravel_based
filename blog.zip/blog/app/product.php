<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{

    //protected $fillable = ['name','price','category_id','slug','description','image','updated_at','created_at'];
    protected $guarded = ['id'];

    public function category()
    {
        return $this->belongsTo('App\Category');
    }

    public function order()
    {
       return $this->hasMany('App\Order');
     }
}
