<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;
use App\Category;

class ShopController extends Controller
{
  public function show($slug)
  {
      $product = product::where('slug', $slug)->firstOrFail();
      $mightAlsoLike = product::where('slug', '!=', $slug)->inRandomOrder()->get();
      
      return view('product')->with([
          'product' => $product,
          'mightAlsoLike' => $mightAlsoLike,
      ]);
  }

  public function category($slug)
  {
      $categories= Category::all();
      $category_id_active= Category::where('slug',$slug)->first()->id;
      $products = product::where('category_id',$category_id_active)->paginate(6);
      return view('categories',['products'=>$products,'categories'=>$categories,'category_id_active'=>$category_id_active]);
  }
}
