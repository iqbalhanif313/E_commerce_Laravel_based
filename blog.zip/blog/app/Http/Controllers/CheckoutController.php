<?php

namespace App\Http\Controllers;

use App\product;
use App\User;
use App\Order;
use App\Checkout;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    public function buy(){


      $userid = Auth::User()->id;
      $orders = Order::with('product')->where('user_id',$userid)->get();

      return view('checkout',['orders'=>$orders]);
    }

    public function pay(Request $request){
     $user = Auth::User();
     $orders = Order::where('user_id',$user->id)->get();

      foreach($orders as $order){

        $new_checkout = new Checkout([
            'name' => $request->name,
            'email' => $request->email,
           'user_id' => $user->id,
           'order_id'=>$order->id,
           'address'=> $request->address,
           'province' =>$request->province,
            'city' => $request->city,
           'zip' => $request->zip,
          'payment' => $request->payment,
          'card_name' => $request->card_name,
          'card_number' => $request->card_number,
         ]);
           $user->checkout()->save($new_checkout,$new_checkout);
      }

      return view('receipt',['orders'=>$orders]);

    }

    public function index(){
        $orders = Order::with('product')->where('user_id',Auth::user()->id)->get();
        if($orders->count()>0){
          return view('receipt',['orders'=>$orders]);
        }else{
          $message = 'You dont have any Orders, You can shop now';

          return redirect()->route('home')->with('message',$message);
        }

    }

    public function arrived(){
      $user = Auth::User();
      $orders = Order::where('user_id',$user->id);
      $checkouts = Checkout::where('user_id',$user->id);

      $checkouts->delete();
      $orders->delete();

      return view('endshop');
    }
}
