<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\product;
use App\Category;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    //public function __construct()
    //{
    //    $this->middleware('auth');
    //  }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $products = product::orderBy('id','desc')->paginate(6);
      $productslider= product::orderBy('id','desc')->take(3)->get();
      $category= Category::all();
        return view('home',['categorys'=>$category,'products'=>$products,'productsliders'=>$productslider]);
    }

    public function contact()
    {
      return view('contact');
    }

    public function about()
    {
      return view('about');
    }
    public function product()
    {
      return view('single');
    }
}
