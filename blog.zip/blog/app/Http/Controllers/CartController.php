<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\product;
use App\User;

class CartController extends Controller
{

    public function guest(){
      $message = 'Please Login To begin Shopping';

      return view('auth.login',['message'=>$message]);
    }

    public function index($user){


      $userid= User::where('name',$user)->first()->id;

      $orders= Order::with('product','user')->where('user_id',$userid)->get();
      return view('cart',['orders'=>$orders]);
    }

    public function add(Request $request,$slug, $userid){

        $product= product::where('slug',$slug)->first();
        $user = User::where('id',$userid)->first();
        $productid= $product->id;
        $quantity= $request->quantity;
        $new_order = new Order([
            'user_id' => $userid,
            'product_id' => $productid ,
            'quantity'=> $quantity
      ]);
      $product->order()->save($new_order);
      $user->order()->save($new_order);
      return redirect(route('cart.index',['user'=>$user->name]));
    }
    public function delete($order_id){
      $order = Order::with('user')->find($order_id);
      $username= $order->user->name;
      $order->delete();
      return redirect(route('cart.index',['user'=>$username]));
    }
}
