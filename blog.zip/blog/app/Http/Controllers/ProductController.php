<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;
use App\Category;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    protected function index(){

      return 'tambah product';
    }

    protected function add(){
      $categories=Category::all();
      return view('newProduct',['categories'=>$categories]);
    }

    protected function addProcess(request $request){
//

        if ($request->hasFile('image')) {
          $imagename = $request->file('image')->getClientOriginalName('public');

          $category = Category::where('name', $request->category)->first();

          $category_id= $category->id;

          $new_cateogry = new product([
              'name' => $request->name,
              'slug' => str_slug($request->name),
              'category_id'=> $category_id,
              'price' =>$request->price,
              'description' => $request->description,
              'image' => $imagename
        ]);

          if($category->products()->save($new_cateogry)&&
            $request->image->storeAs('public',$imagename))
            return  redirect()->route('product.list');
        }else {
          return 'g ada file';
        }



    }
    protected function list(){
      $products = product::orderBy('id','desc')->get();

      return view('listProduct',['products'=>$products]);
    }

    protected function delete(Request $request){
      $product = product::find($request->id);

      $productimage = 'public/'.$product->image;
      Storage::delete($productimage);
      $product->delete();



      return  redirect()->route('product.list');
    }

    protected function update($id){
      $product = product::find($id);
      $categories=Category::all();

      return view('updateProduct',['categories'=>$categories,'product'=>$product]);
    }

    protected function updateProsses(Request $request, $id){

      $product = product::find($id);
      $category = Category::where('name', $request->category)->first();

        if ($request->hasFile('image')) {

                $imagename = $request->file('image')->getClientOriginalName('public');
                $request->image->storeAs('public',$imagename);
                $product->image = $imagename;

        }

        $product->name = $request->name;
        $product->price = $request->price;
        $product->slug = str_slug($request->name);
        $product->description=  $request->description;

        $product->category()->associate($category);
        $product->save();
        return  redirect()->route('product.list');

    }
}
