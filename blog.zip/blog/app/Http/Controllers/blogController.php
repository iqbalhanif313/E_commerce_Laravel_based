<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class blogController extends Controller
{
    public function index()
    {
      $unescaped = '<script>alert("x!")</script>';
      $users= ['muhammad','hanif',' iqbal',' hanif','iqbal'];
      return view('blog/home',['orangs' => $users,'unescaped' => $unescaped]);
    }
    public function show($id)
    {
      $nilai = 'ini adalah nilainya' . $id;
      $users= DB::table('users')->get();
      dd($users);
    	return view('blog/single',['blog' => $nilai,'orangs' => $users]);
    }
}
