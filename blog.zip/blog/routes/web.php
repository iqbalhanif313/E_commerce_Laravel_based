<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/contact', 'HomeController@contact')->name('contact');
Route::get('/about', 'HomeController@about')->name('about');

Route::get('/shop', 'shopController@index')->name('shop.index');
Route::get('/shop/{slug}', 'ShopController@show')->name('shop.show');

Route::get('categories/{slug}', 'ShopController@category')->name('category.show');

Route::get('/new-product', 'ProductController@add')->name('product.new');
Route::post('/new-product', 'ProductController@addProcess');

Route::get('/list-product', 'ProductController@list')->name('product.list');

Route::get('/delete-product/{id}', 'ProductController@delete')->name('product.delete');

Route::get('/update-product/{id}', 'ProductController@update')->name('product.update');
Route::post('/update-product/{id}', 'ProductController@updateProsses');

Route::get('/cart','CartController@guest')->name('cart.guest');
Route::get('/cart/{user}','CartController@index')->name('cart.index');
Route::get('/cart/add/{slug}/{user_id}','CartController@add')->name('cart.add');
Route::get('/cart/delete/{order_id}','CartController@delete')->name('cart.delete');


Route::get('/checkout','CheckoutController@buy')->name('checkout.buy');
Route::post('/checkout','CheckoutController@pay');
Route::get('/my-orders','CheckoutController@index')->name('checkout.index');
Route::get('/confirm','CheckoutController@arrived')->name('checkout.arrived');
