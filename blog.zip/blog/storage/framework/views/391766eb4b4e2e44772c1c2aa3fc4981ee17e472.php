<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>
    <header>
      <nav>
        <a href='/'>home</a>
        <a href='/blog'>Blog</a>
      </nav>
    </header>
    <br>
    <?php echo $__env->yieldContent('content'); ?>
    </br>
    <footer>
      <p>
        &copy; laravel $sekolahkoding 2016
      </p>
    </footer>
  </body>
</html>
