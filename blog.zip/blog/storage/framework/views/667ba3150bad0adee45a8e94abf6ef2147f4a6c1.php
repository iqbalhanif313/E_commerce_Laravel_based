<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-offset-1">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Total</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                  <?php
                  $subtotal=0;
                  ?>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="col-sm-8 col-md-6">
                        <div class="media">
                            <a class="thumbnail pull-left" href="#"> <img class="media-object" src="<?php echo e(Storage::url($order->product->image)); ?>" style="width: 72px; height: 72px;"> </a>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="#"><?php echo e($order->product->name); ?></a></h4>
                                <h5 class="media-heading"> by <a href="#"><?php echo e($order->user->name); ?></a></h5>
                            </div>
                        </div></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong><?php echo e($order->quantity); ?></strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong><?php echo e($order->product->price); ?></strong></td>
                        <?php
                        $a = $order->quantity;
                        $b = $order->product->price;
                        $c = $b*$a;
                        $subtotal=$subtotal+$c;
                        ?>
                        <td class="col-sm-1 col-md-1 text-center"><strong><?php echo ($c); ?></strong></td>
                        <td class="col-sm-1 col-md-1">
                        <a href="<?php echo e(route('cart.delete',$order->id)); ?>" type="button" class="btn btn-danger">
                            <span class="glyphicon glyphicon-remove"></span> Remove
                        </a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h5>Subtotal</h5></td>
                        <td class="text-right"><h5><strong><?php echo ($subtotal); ?></strong></h5></td>
                    </tr>
                    <?php
                    $shipping = $subtotal*10/100;
                    $total = $shipping+$subtotal;
                    ?>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h5>Estimated shipping</h5></td>
                        <td class="text-right"><h5><strong><?php echo ($shipping); ?></strong></h5></td>
                    </tr>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h3>Total</h3></td>
                        <td class="text-right"><h3><strong><?php echo ($total); ?></strong></h3></td>
                    </tr>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td>
                        <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-default">
                            <span class="glyphicon glyphicon-shopping-cart"></span> Continue Shopping
                        </a></td>
                        <td>
                        <a href="<?php echo e(route('checkout.buy')); ?>" type="button" class="btn btn-success">
                            Checkout <span class="glyphicon glyphicon-play"></span>
                        </a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>