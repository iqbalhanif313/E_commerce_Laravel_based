
<?php $__env->startSection('content'); ?>
<div class="jumbotron text-xs-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further info of your shopping details</p>
  <hr>
  <p>
    Having trouble? <a href="<?php echo e(route('contact')); ?>">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="<?php echo e(route('home')); ?>" role="button">Continue to homepage</a>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>