<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
        <div class="col-lg-9">
        	<iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCoXzLAVPnYkRsl5GOBUL2q-IZGmJyFGVk&q=Politeknik+Elektronika+Negeri+Surabaya"></iframe>
    	</div>

      	<div class="col-lg-3">
    		<h2>Kunjungi Kami</h2>
    		<address>
    			<strong>Politenik Elektronika Negeri Surabaya</strong><br>
    			Jln Raya ITS Keputih<br>
    			Keputih<br>
    			Sukolilo<br>
    			Surabaya<br>
    			60111<br>
    			<abbr title="Phone">P:</abbr> 081235313982
    		</address>
    	</div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>