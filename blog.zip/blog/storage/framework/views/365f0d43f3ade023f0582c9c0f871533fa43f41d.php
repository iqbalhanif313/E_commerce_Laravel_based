<?php $__env->startSection('title','Bismillah dulu ya'); ?>

<?php $__env->startSection('content'); ?>
  <h1>Selamat datang di Blog Kami</h1>
  <p> selamat datang gitu loh di blog kami</p>

  <?php $__currentLoopData = $orangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($orang); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php echo $unescaped; ?>


  <?php if(count($orangs)>3): ?>
    <p>Usernya ada lebih dari tiga</p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>