<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row ">
        <div class="col-md-10 col-md-offset-3 ">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <address>
                        <strong>Elf Cafe</strong>
                        <br>
                        2135 Sunset Blvd
                        <br>
                        Los Angeles, CA 90026
                        <br>
                        <abbr title="Phone">P:</abbr> (213) 484-6829
                    </address>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                    <p>
                        <em>Date: 1st November, 2013</em>
                    </p>
                    <p>
                        <em>Receipt #: 34522677W</em>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="text-center">
                    <h1>Receipt</h1>
                </div>
                </span>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>#</th>
                            <th class="text-center">Price</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                      $subtotal=0;
                      ?>
                      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="col-md-9"><em><?php echo e($order->product->name); ?></em></h4></td>
                            <td class="col-md-1" style="text-align: center"> <?php echo e($order->quantity); ?></td>
                            <td class="col-md-1 text-center"><?php echo e($order->product->price); ?></td>
                            <td class="col-md-1 text-center"><?php echo e($order->quantity*$order->product->price); ?></td>
                        </tr>
                        <?php
                        $a = $order->quantity;
                        $b = $order->product->price;
                        $c = $b*$a;
                        $subtotal=$subtotal+$c;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $shipping = $subtotal*10/100;
                        $total = $shipping+$subtotal;
                        ?>
                        <tr>
                            <td>   </td>
                            <td>   </td>
                            <td class="text-right">
                            <p>
                                <strong>Subtotal: </strong>
                            </p>
                            <p>
                                <strong>Shipping (10%):  </strong>
                            </p></td>
                            <td class="text-center">
                            <p>
                                <strong><?php echo e($subtotal); ?></strong>
                            </p>
                            <p>
                                <strong><?php echo e($shipping); ?></strong>
                            </p></td>
                        </tr>
                        <tr>
                            <td>   </td>
                            <td>   </td>
                            <td class="text-right"><h4><strong>Total: </strong></h4></td>
                            <td class="text-center text-danger"><h4><strong><?php echo e($total); ?></strong></h4></td>
                        </tr>
                    </tbody>
                </table>
                <a href="<?php echo e(route('checkout.arrived')); ?>" type="button" class="btn btn-success btn-lg btn-block">
                    Orders Arrived   <span class="glyphicon glyphicon-chevron-right"></span>
                </a></td>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>