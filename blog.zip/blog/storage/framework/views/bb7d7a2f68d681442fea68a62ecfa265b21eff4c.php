<?php $__env->startSection('content'); ?>
<div class="container">

  <section class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Tambah Product</h3>
</div>
<br><br>
<div class="panel-body">

  <form method="POST" action="<?php echo e(route('product.update',$product->id)); ?>" class="form-horizontal" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Nama Product</label>
      <div class="col-sm-9">
        <input type="text" class="form-control" name="name" id="name" value="<?php echo e($product->name); ?>">
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Price</label>
      <div class="col-sm-9">
        <input type="number" class="form-control" name="price" id="name" value="<?php echo e($product->price); ?>">
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="about" class="col-sm-3 control-label">Description</label>
      <div class="col-sm-9">
        <textarea name="description" class="form-control"><?php echo e($product->description); ?>"</textarea>
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="tech" class="col-sm-3 control-label">Category</label>
      <div class="col-sm-3">
        <select class="form-control" name="category">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Gambar Product</label>
      <div class="col-sm-3">
        <label class="control-label small" for="image">Gambar Utama (jpg/png):</label> <input type="file" name="image" choosen="<?php echo e($product->image); ?>">
      </div>

    <div class="form-group">
      <div class="col-sm-offset-3 col-sm-9">
        <button type="submit" class="btn btn-primary">Add Product</button>
      </div>
    </div> <!-- form-group // -->
  </form>

</div><!-- panel-body // -->
</section><!-- panel// -->


</div> <!-- container// -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>