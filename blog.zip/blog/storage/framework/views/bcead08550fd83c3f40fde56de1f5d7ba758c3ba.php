<?php $__env->startSection('content'); ?>


<!------ Include the above in your HEAD tag ---------->

<div class="card">
	<div class="row">
		<aside class="col-sm-5 border-right">
<article class="gallery-wrap">
<div class="img-big-wrap">
  <div> <a href="#"><img class="embed-responsive" src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="product"></a></div>
</div>

</article> <!-- gallery-wrap .end// -->
		</aside>
		<aside class="col-sm-7">
<article class="card-body p-5">
	<h3 class="title mb-3"><?php echo e($product->name); ?></h3>

<p class="price-detail-wrap">
	<span class="price h3 text-warning">
		<span class="currency">US $</span><span class="num">1299</span>
	</span>
	<span>/per kg</span>
</p> <!-- price-detail-wrap .// -->
<dl class="item-property">
  <dt>Description</dt>
  <dd><p><?php echo e($product->description); ?> </p></dd>
</dl>
<dl class="param param-feature">
  <dt>Model#</dt>
  <dd>12345611</dd>
</dl>  <!-- item-property-hor .// -->
<dl class="param param-feature">
  <dt>Color</dt>
  <dd>Black and white</dd>
</dl>  <!-- item-property-hor .// -->
<dl class="param param-feature">
  <dt>Delivery</dt>
  <dd>Russia, USA, and Europe</dd>
</dl>  <!-- item-property-hor .// -->

<hr>
<?php echo e(csrf_field()); ?>

<?php if(auth()->guard()->guest()): ?>
<form action="<?php echo e(route('cart.guest')); ?>" method="get">
<?php else: ?>
<form action="<?php echo e(route('cart.add',[$product->slug, Auth::user()->id])); ?>" method="get">
<?php endif; ?>

	<div class="row">

		<div class="col-sm-5">
			<dl class="param param-inline">
			  <dt>Quantity: </dt>
			  <dd>
			  	<input name="quantity" value="1" type="number" style="width:70px;">
			  </dd>
			</dl>  <!-- item-property .// -->
		</div> <!-- col.// -->

	</div> <!-- row.// -->
	<hr>
	<button type="submit"  class="btn btn-lg btn-primary text-uppercase">ADD TO CART</button>
	</form>
	
		</aside> <!-- col.// -->
	</div> <!-- row.// -->
</div> <!-- card.// -->


</div>
<!--container.//-->


<br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>