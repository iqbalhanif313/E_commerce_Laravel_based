<!DOCTYPE html>
<html>
  <head>
    <title>Home</title>
  </head>
  <body>
    <h1>Selamat datang diblog ini</h1>
    <h2><?php echo e($blog); ?></h2>

    <?php foreach ($orangs as $orang ): ?>
        <li><?php echo e($orang -> username.' '. $orang->password); ?></li>
    <?php endforeach; ?>
    dd($orangs);
    <h3><?php echo e($blog); ?></h3>
  </body>
</html>
