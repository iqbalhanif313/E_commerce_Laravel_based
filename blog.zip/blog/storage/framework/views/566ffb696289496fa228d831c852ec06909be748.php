<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>

<title>List Of Products</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

</head>
<body>
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>List of <b>Products</b></h2></div>
                    <div class="col-sm-4">
                        <a href="<?php echo e(route('product.new')); ?>" class="btn btn-info add-new"><i class="fa fa-plus"></i> Add New</a>
                    </div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Category Id</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $a=1; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $a ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->category_id); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td>
                            <a type="button" href="<?php echo e(route('product.update',$product->id)); ?>" class="btn btn-default btn-sm"><i class="material-icons">&#xE254;</i></a>
                            <a type="button" href="<?php echo e(route('product.delete',$product->id)); ?>" class="btn btn-default btn-sm"><i class="material-icons">&#xE872;</i></a>
                        </td>
                    </tr>
                    <?php $a++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>