<?php $__env->startSection('content'); ?>
<body class="bg-light" style="">

    <div class="container">


      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
            <span class="badge badge-secondary badge-pill">3</span>
          </h4>
          <?php
          $subtotal=0;
          ?>

          <ul class="list-group mb-3">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $a = $order->quantity;
            $b = $order->product->price;
            $c = $b*$a;
            $subtotal=$subtotal+$c;
            ?>
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h6 class="my-0"><?php echo e($order->product->name); ?></h6>
                <small class="text-muted"><?php echo e($order->quantity); ?> pcs x <?php echo e($order->product->price); ?></small>
              </div>
              <span class="text-muted"><?php echo e($c); ?></span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
            $shipping = $subtotal*10/100;
            $total = $shipping+$subtotal;
            ?>

            <li class="list-group-item d-flex justify-content-between">
              <span>Shipping (10%)</span>
              <strong><?php echo e($shipping); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (IDR)</span>
              <strong><?php echo e($total); ?></strong>
            </li>
          </ul>

          <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code">
              <div class="input-group-append">
                <button type="submit" class="btn btn-secondary">Redeem</button>
              </div>
            </div>
          </form>
        </div>
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3">Billing address</h4>



          <form action="<?php echo e(route('checkout.buy')); ?>" class="form-group" method="POST" >
            <?php echo e(csrf_field()); ?>

            <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label for="firstName">Buyer Name</label>
                <input type="text" class="form-control" name="name" placeholder="" value="" required="">
              </div>
            <div class="mb-3">
              <label for="email">Email <span class="text-muted">(Optional)</span></label>
              <input type="email" class="form-control" name="email" placeholder="you@example.com">
            </div>
            <div class="mb-3">
              <label for="address">Address</label>
              <textarea type="text" class="form-control" name="address" placeholder="1234 Main St" required="">  </textarea>
            </div>
            <div class="row">
              <div class="col-md-5 mb-3">
                <label for="country">Province</label>
                <input type="text" class="form-control d-block w-100" name="province" required="">
              </div>
              <div class="col-md-4 mb-3">
                <label for="state">City</label>
                <input type="text" class="form-control d-block w-100" name="city" required="">
              </div>
              <div class="col-md-3 mb-3">
                <label for="zip">Zip</label>
                <input type="number" class="form-control" name="zip" placeholder="" required="">
              </div>
            </div>
            <hr class="mb-4">

            <h4 class="mb-3">Payment</h4>

            <div class="d-block my-3">
              <div class="custom-control custom-radio">
                <input id="credit" name="payment" type="radio" class="custom-control-input" value="credit card" checked="" required="">
                <label class="custom-control-label" for="credit">Credit card</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="debit" name="payment" type="radio" class="custom-control-input" value="debit card" required="">
                <label class="custom-control-label" for="debit">Debit card</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="paypal" name="payment" type="radio" class="custom-control-input" value="paypal" required="">
                <label class="custom-control-label" for="paypal">Paypal</label>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="cc-name">Name on card</label>
                <input type="text" class="form-control" name="card_name" placeholder="" required="">
                <small class="text-muted">Full name as displayed on card</small>
                <div class="invalid-feedback">
                  Name on card is required
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="cc-number">Credit card number</label>
                <input type="number" class="form-control" name="card_number" placeholder="" required="">
                <div class="invalid-feedback">
                  Credit card number is required
                </div>
              </div>
            </div>
            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
          </form>
        </div>
      </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">© 2017-2018 Company Name</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Privacy</a></li>
          <li class="list-inline-item"><a href="#">Terms</a></li>
          <li class="list-inline-item"><a href="#">Support</a></li>
        </ul>
      </footer>
    </div>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>