@extends('layouts.app')
@section('content')
<div class="container">

  <section class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Tambah Product</h3>
</div>
<br><br>
<div class="panel-body">

  <form method="POST" action="{{route('product.new')}}" class="form-horizontal" enctype="multipart/form-data">
      @csrf

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Nama Product</label>
      <div class="col-sm-9">
        <input type="text" class="form-control" name="name" id="name" placeholder="Nama Product">
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Price</label>
      <div class="col-sm-9">
        <input type="number" class="form-control" name="price" id="name" placeholder="price">
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="about" class="col-sm-3 control-label">Description</label>
      <div class="col-sm-9">
        <textarea name="description" class="form-control"></textarea>
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="tech" class="col-sm-3 control-label">Category</label>
      <div class="col-sm-3">
        <select class="form-control" name="category">
          @foreach($categories as $category)
          <option value="{{$category->name}}">{{$category->name}}</option>
          @endforeach
        </select>
      </div>
    </div> <!-- form-group // -->

    <div class="form-group">
      <label for="name" class="col-sm-3 control-label">Gambar Product</label>
      <div class="col-sm-3">
        <label class="control-label small" for="image">Gambar Utama (jpg/png):</label> <input type="file" name="image">
      </div>

    <div class="form-group">
      <div class="col-sm-offset-3 col-sm-9">
        <button type="submit" class="btn btn-primary">Add Product</button>
      </div>
    </div> <!-- form-group // -->
  </form>

</div><!-- panel-body // -->
</section><!-- panel// -->


</div> <!-- container// -->
@endsection
