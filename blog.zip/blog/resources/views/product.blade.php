@extends('layouts.app')
@section('content')


<!------ Include the above in your HEAD tag ---------->

<div class="card">
	<div class="row">
		<aside class="col-sm-5 border-right">
<article class="gallery-wrap">
<div class="img-big-wrap">
  <div> <a href="#"><img class="embed-responsive" src="{{asset('storage/'.$product->image)}}" alt="product"></a></div>
</div>

</article> <!-- gallery-wrap .end// -->
		</aside>
		<aside class="col-sm-7">
<article class="card-body p-5">
	<h3 class="title mb-3">{{$product->name}}</h3>

<p class="price-detail-wrap">
	<span class="price h3 text-warning">
		<span class="currency">US $</span><span class="num">1299</span>
	</span>
	<span>/per kg</span>
</p> <!-- price-detail-wrap .// -->
<dl class="item-property">
  <dt>Description</dt>
  <dd><p>{{$product->description}} </p></dd>
</dl>
<dl class="param param-feature">
  <dt>Model#</dt>
  <dd>12345611</dd>
</dl>  <!-- item-property-hor .// -->
<dl class="param param-feature">
  <dt>Color</dt>
  <dd>Black and white</dd>
</dl>  <!-- item-property-hor .// -->
<dl class="param param-feature">
  <dt>Delivery</dt>
  <dd>Russia, USA, and Europe</dd>
</dl>  <!-- item-property-hor .// -->

<hr>
{{ csrf_field() }}
@guest
<form action="{{route('cart.guest')}}" method="get">
@else
<form action="{{route('cart.add',[$product->slug, Auth::user()->id])}}" method="get">
@endguest

	<div class="row">

		<div class="col-sm-5">
			<dl class="param param-inline">
			  <dt>Quantity: </dt>
			  <dd>
			  	<input name="quantity" value="1" type="number" style="width:70px;">
			  </dd>
			</dl>  <!-- item-property .// -->
		</div> <!-- col.// -->

	</div> <!-- row.// -->
	<hr>
	<button type="submit"  class="btn btn-lg btn-primary text-uppercase">ADD TO CART</button>
	</form>
	
		</aside> <!-- col.// -->
	</div> <!-- row.// -->
</div> <!-- card.// -->


</div>
<!--container.//-->


<br><br><br>

@endsection
