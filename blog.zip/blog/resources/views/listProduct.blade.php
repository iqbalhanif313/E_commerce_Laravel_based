@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>

<title>List Of Products</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

</head>
<body>
    @csrf
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>List of <b>Products</b></h2></div>
                    <div class="col-sm-4">
                        <a href="{{route('product.new')}}" class="btn btn-info add-new"><i class="fa fa-plus"></i> Add New</a>
                    </div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Category Id</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $a=1; ?>
                @foreach($products as $product)
                    <tr>
                        <td><?php echo $a ?></td>
                        <td>{{$product->name}}</td>
                        <td>{{$product->price}}</td>
                        <td>{{$product->category_id}}</td>
                        <td>{{$product->description}}</td>
                        <td>
                            <a type="button" href="{{route('product.update',$product->id)}}" class="btn btn-default btn-sm"><i class="material-icons">&#xE254;</i></a>
                            <a type="button" href="{{route('product.delete',$product->id)}}" class="btn btn-default btn-sm"><i class="material-icons">&#xE872;</i></a>
                        </td>
                    </tr>
                    <?php $a++; ?>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

@endsection
