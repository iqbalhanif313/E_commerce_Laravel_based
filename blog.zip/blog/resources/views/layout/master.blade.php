<!DOCTYPE html>
<html>
  <head>
    <title>@yield('title')</title>
  </head>
  <body>
    <header>
      <nav>
        <a href='/'>home</a>
        <a href='/blog'>Blog</a>
      </nav>
    </header>
    <br>
    @yield('content')
    </br>
    <footer>
      <p>
        &copy; laravel $sekolahkoding 2016
      </p>
    </footer>
  </body>
</html>
