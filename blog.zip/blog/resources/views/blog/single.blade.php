<!DOCTYPE html>
<html>
  <head>
    <title>Home</title>
  </head>
  <body>
    <h1>Selamat datang diblog ini</h1>
    <h2>{{ $blog }}</h2>

    <?php foreach ($orangs as $orang ): ?>
        <li>{{$orang -> username.' '. $orang->password}}</li>
    <?php endforeach; ?>
    <h3>{{ $blog }}</h3>
  </body>
</html>
