@extends('layout.master')

@section('title','Bismillah dulu ya')

@section('content')
  <h1>Selamat datang di Blog Kami</h1>
  <p> selamat datang gitu loh di blog kami</p>

  @foreach($orangs as $orang)
    <li>{{$orang}}</li>
  @endforeach

  {!! $unescaped !!}

  @if(count($orangs)>3)
    <p>Usernya ada lebih dari tiga</p>
  @endif
@endsection
